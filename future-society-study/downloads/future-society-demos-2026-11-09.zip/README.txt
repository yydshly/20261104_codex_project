未来社会演示存档｜2026-11-09

解压后，用支持 WebGL 的浏览器打开 play 文件夹中的 HTML。
已有的语音随页面保存，在页面内点击「听讲解」。

blackout-2031.html      停电后的 20 分钟
future-grid-2031.html   2031 · 现场接入演练
ai-world-2031.html      2031 · AI 主导的一天
city-system-2031.html   2031 · 城市运行实验（含 AI 价值对照与 MiniMax 讲解）

source 为可继续编辑的源文件，images 为部分画面截图。
