import { cp, mkdir, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('..', import.meta.url));
await mkdir(path.join(root, 'dist'), { recursive: true });
for (const name of ['index.html', 'study.html', 'src', 'vendor', 'assets', 'docs', 'README.md']) {
  await cp(path.join(root, name), path.join(root, 'dist', name), { recursive: true });
}
for (const name of ['play.html', 'deliverables']) {
  try { await access(path.join(root, name)); await cp(path.join(root, name), path.join(root, 'dist', name), { recursive: true }); } catch (error) { if (error.code !== 'ENOENT') throw error; }
}
await mkdir(path.join(root, 'dist', 'deliverables'), { recursive: true });
try { await cp(path.join(root, 'engine', 'Emberfall-Godot-project.zip'), path.join(root, 'dist', 'deliverables', 'Emberfall-Godot-project.zip')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
console.log('Static build saved to dist/');
